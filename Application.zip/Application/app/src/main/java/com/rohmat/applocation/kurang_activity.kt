package com.rohmat.applocation

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.databinding.DataBindingUtil
import com.rohmat.applocation.databinding.ActivityKurangActivityBinding

class kurang_activity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val binding: ActivityKurangActivityBinding = DataBindingUtil.setContentView(this, R.layout.activity_kurang_activity)

        binding.btnKurang.setOnClickListener {
            if (binding.edtAngka1.text.toString() == null || binding.edtAngka2.text.toString() == null
                    || binding.edtAngka1.text.toString().trim() == "" || binding.edtAngka2.text.toString().trim() == ""){

                Toast.makeText(this, "Silahkan Inputkan Data", Toast.LENGTH_SHORT).show()
            }else{

                val n1 = binding.edtAngka1.text.toString().toInt()
                val n2 = binding.edtAngka2.text.toString().toInt()

                val value = n1-n2

                binding.txtHasil.text = value.toString()
            }
        }
    }
}