package com.rohmat.applocation

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class Dasboard_Activity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dasboard_)
    }
}