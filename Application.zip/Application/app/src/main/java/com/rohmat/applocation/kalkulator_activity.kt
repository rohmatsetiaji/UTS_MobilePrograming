package com.rohmat.applocation

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.databinding.DataBindingUtil
import com.rohmat.applocation.databinding.ActivityKalkulatorActivityBinding

class kalkulator_activity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //setContentView(R.layout.activity_kalkulator_activity)

        val binding: ActivityKalkulatorActivityBinding = DataBindingUtil.setContentView(this, R.layout.activity_kalkulator_activity)

        binding.btnTambah.setOnClickListener {
            startActivity(Intent(this, tambah_activity::class.java))
        }
        binding.btnKurang.setOnClickListener {
            startActivity(Intent(this, kurang_activity::class.java))
        }
        binding.btnKali.setOnClickListener {
            startActivity(Intent(this, kali_activity::class.java))
        }
        binding.btnBagi.setOnClickListener {
            startActivity(Intent(this, bagi_activity::class.java))
        }


    }
}