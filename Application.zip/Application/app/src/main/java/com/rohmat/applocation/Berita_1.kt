package com.rohmat.applocation

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class Berita_1 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_berita_1)
    }
}